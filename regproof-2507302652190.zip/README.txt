This zip file contains the files that constitute the technological evidence that unequivocally 
identifies the work provided and the date of possession and therefore priority, for the defense 
of intellectual property rights according to the principle "Prior tempore, potior iure".

Registry information
--------------------
Safe Creative Registration No 2507302652190
Name of the provided file with the work or its description: campo_conciencia_ecuacion_dimensional_autor.pdf
Date of registration: 2025-07-30 12:43:41 
MD5 hash: 5c0a0a614f6cf8e76e8326bf7f1c2c9b
SHA-1 hash: f91ef1c21f631590348e8e760187114c96e66dc2
SHA-256 hash: 433de02b7e49587951f70cf0223cbe75a54a69f22157e28793c1d9c1964f18ff

The page available at: https://www.safecreative.org/work/2507302652190 offers information 
on the registration and download of the provided file, if the registrant allows public access to them.
 
Content files that constitute the proof:
--------------------------------------------------
● 	File provided at the time of registration with the work or its description.
● 	Identifier of the file provided: 
	File containing the cryptographic hashes that allow to identify unequivocally the file with the registered work or 
	description, together with the size in bytes and the date of the registration. The file contains the following 
	values, separated by plus signs (+) 
	- Registration date (in milliseconds from January 1, 1970). 
	- Size in bytes of the provided file. 
	- SHA-1 hash of the provided file. 
	- SHA-256 hash of the provided file. 
	- SHA 512 hash of the provided file.
● 	Time stamping of the identifier described above. 
	They prove the date and time in which the registration was made, and therefore the priority date used in the defense 
	of intellectual copyrights.
